package com.library.Library.controller;

import com.library.Library.entity.BorrowBook;
import com.library.Library.service.BorrowBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/borrowBooks")
public class BorrowBookController {

    @Autowired
    private BorrowBookService borrowBookService;

    @GetMapping ()
    public List<BorrowBook> getAllBorrowedBooks() {
        return borrowBookService.getAllBorrowedBooks();
    }

    @GetMapping("/{id}")
    public ResponseEntity<BorrowBook> getBorrowedBookById(@PathVariable Long id) {
        return borrowBookService.getBorrowedBookById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping()
    public BorrowBook borrowBook(@RequestBody BorrowBook borrowBook) {
        return borrowBookService.borrowBook(borrowBook);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> returnBook(@PathVariable Long id) {
        borrowBookService.returnBook(id);
        return ResponseEntity.noContent().build();
    }
}
