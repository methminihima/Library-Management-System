package com.library.Library.repository;

import com.library.Library.entity.Staff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StaffRepository  extends JpaRepository<Staff, Long> {
}
