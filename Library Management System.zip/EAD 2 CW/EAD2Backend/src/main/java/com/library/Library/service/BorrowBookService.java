package com.library.Library.service;

import com.library.Library.entity.BorrowBook;
import com.library.Library.repository.BorrowBookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BorrowBookService {

    @Autowired
    private BorrowBookRepository borrowBookRepository;

    public List<BorrowBook> getAllBorrowedBooks() {
        return borrowBookRepository.findAll();
    }

    public Optional<BorrowBook> getBorrowedBookById(Long id) {
        return borrowBookRepository.findById(id);
    }

    public BorrowBook borrowBook(BorrowBook borrowBook) {
        return borrowBookRepository.save(borrowBook);
    }

    public void returnBook(Long id) {
        borrowBookRepository.deleteById(id);
    }
}
