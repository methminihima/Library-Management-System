let members = [];
let editMode = false;
let editingMemberId = null;

// DOM Elements
const memberForm = document.getElementById("member-form");
const membersTable = document.getElementById("members-table").querySelector("tbody");
const formTitle = document.getElementById("form-title");
const submitButton = document.getElementById("submit-button");

// Function to go back to the home page
function goToHomePage() {
    window.location.href = "home.html"; // Replace with your actual home page file name
}


// Add or Update Member
memberForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const membershipDate = document.getElementById("membershipDate").value.trim();
    const active = document.getElementById("active").checked;

    if (editMode) {
        // Update Member
        const member = members.find(member => member.id === editingMemberId);
        member.name = name;
        member.email = email;
        member.membershipDate = membershipDate;
        member.active = active;
        editMode = false;
        editingMemberId = null;
        formTitle.textContent = "Add Member";
        submitButton.textContent = "Add Member";
    } else {
        // Add New Member
        const newMember = {
            id: Date.now(),
            name,
            email,
            membershipDate,
            active
        };
        members.push(newMember);
    }

    renderMembersTable();
    memberForm.reset();
});

// Render Members Table
function renderMembersTable() {
    membersTable.innerHTML = "";
    members.forEach(member => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${member.id}</td>
            <td>${member.name}</td>
            <td>${member.email}</td>
            <td>${member.membershipDate}</td>
            <td>${member.active ? "Active" : "Inactive"}</td>
            <td class="actions">
                <button class="edit-btn" onclick="editMember(${member.id})">Edit</button>
                <button class="delete-btn" onclick="deleteMember(${member.id})">Delete</button>
                <button class="toggle-btn" onclick="toggleMemberStatus(${member.id})">${member.active ? "Deactivate" : "Activate"}</button>
            </td>
        `;

        membersTable.appendChild(row);
    });
}

// Edit Member
function editMember(id) {
    const member = members.find(member => member.id === id);

    document.getElementById("name").value = member.name;
    document.getElementById("email").value = member.email;
    document.getElementById("membershipDate").value = member.membershipDate;
    document.getElementById("active").checked = member.active;

    editMode = true;
    editingMemberId = id;
    formTitle.textContent = "Edit Member";
    submitButton.textContent = "Update Member";
}

// Delete Member
function deleteMember(id) {
    if (confirm("Are you sure you want to delete this member?")) {
        members = members.filter(member => member.id !== id);
        renderMembersTable();
    }
}

// Toggle Member Status (Activate/Deactivate)
function toggleMemberStatus(id) {
    const member = members.find(member => member.id === id);
    member.active = !member.active;
    alert(`Member "${member.name}" is now ${member.active ? "Active" : "Inactive"}.`);
    renderMembersTable();
}

function validateContactNumber(input) {
    // Remove any non-numeric characters
    input.value = input.value.replace(/\D/g, '');

    // Ensure the length does not exceed 10 digits
    if (input.value.length > 10) {
        input.value = input.value.slice(0, 10);
    }
}

