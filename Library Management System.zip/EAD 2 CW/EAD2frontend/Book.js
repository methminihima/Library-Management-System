let books = [];
let editMode = false;
let editingBookId = null;

// DOM Elements
const bookForm = document.getElementById("book-form");
const booksTable = document.getElementById("books-table").querySelector("tbody");
const formTitle = document.getElementById("form-title");
const submitButton = document.getElementById("submit-button");

// Add Book or Update Book
bookForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const title = document.getElementById("title").value.trim();
    const author = document.getElementById("author").value.trim();
    const isbn = document.getElementById("isbn").value.trim();
    const copiesAvailable = parseInt(document.getElementById("copiesAvailable").value.trim(), 10);
    const description = document.getElementById("description").value.trim();
    const price = parseFloat(document.getElementById("price").value.trim());

    if (editMode) {
        // Update existing book
        const book = books.find(book => book.id === editingBookId);
        book.title = title;
        book.author = author;
        book.isbn = isbn;
        book.copiesAvailable = copiesAvailable;
        book.description = description;
        book.price = price;

        editMode = false;
        editingBookId = null;
        formTitle.textContent = "Add Book";
        submitButton.textContent = "Add Book";
    } else {
        // Add new book
        const newBook = {
            id: Date.now(),
            title,
            author,
            isbn,
            copiesAvailable,
            description,
            price,
        };
        books.push(newBook);
    }

    renderBooksTable();
    bookForm.reset();
});

// Render Table
function renderBooksTable() {
    booksTable.innerHTML = "";
    books.forEach(book => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${book.id}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.isbn}</td>
            <td>${book.copiesAvailable}</td>
            <td>${book.description}</td>
            <td>Rs${book.price.toFixed(2)}</td>
            <td class="actions">
                <button class="edit-btn" onclick="editBook(${book.id})">Edit</button>
                <button class="delete-btn" onclick="deleteBook(${book.id})">Delete</button>
                <button class="borrow-btn" onclick="borrowBook(${book.id})">Borrow</button>
            </td>
        `;

        booksTable.appendChild(row);
    });
}

// Edit Book
function editBook(id) {
    const book = books.find(book => book.id === id);

    document.getElementById("title").value = book.title;
    document.getElementById("author").value = book.author;
    document.getElementById("isbn").value = book.isbn;
    document.getElementById("copiesAvailable").value = book.copiesAvailable;
    document.getElementById("description").value = book.description;
    document.getElementById("price").value = book.price;

    editMode = true;
    editingBookId = id;
    formTitle.textContent = "Edit Book";
    submitButton.textContent = "Update Book";
}

// Delete Book
function deleteBook(id) {
    books = books.filter(book => book.id !== id);
    renderBooksTable();
}

// Borrow Book
function borrowBook(id) {
    const book = books.find(book => book.id === id);
    if (book.copiesAvailable > 0) {
        book.copiesAvailable -= 1;
        alert(`Borrowed 1 copy of "${book.title}".`);
    } else {
        alert(`No copies of "${book.title}" are available to borrow.`);
    }
    renderBooksTable();
}
