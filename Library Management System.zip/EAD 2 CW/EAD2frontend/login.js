document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get the username and password values
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Basic validation
    if (username === "" || password === "") {
        document.getElementById("error-message").textContent = "Please enter both username and password.";
        return;
    }

    // Dummy login check (replace with actual authentication logic)
    if (username === "user" && password === "password") {
        alert("Login Successful");
        window.location.href = "dashboard.html";  // Redirect to the dashboard or another page after successful login
    } else {
        document.getElementById("error-message").textContent = "Invalid username or password.";
    }
});
