let staffMembers = [];
let editMode = false;
let editingStaffId = null;

// DOM Elements
const staffForm = document.getElementById("staff-form");
const staffTable = document.getElementById("staff-table").querySelector("tbody");
const formTitle = document.getElementById("form-title");
const submitButton = document.getElementById("submit-button");

// Add or Update Staff Member
staffForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const joiningDate = document.getElementById("joiningDate").value.trim();
    const address = document.getElementById("address").value.trim();
    const active = document.getElementById("active").checked;

    if (editMode) {
        // Update Staff Member
        const staff = staffMembers.find(staff => staff.id === editingStaffId);
        staff.name = name;
        staff.email = email;
        staff.joiningDate = joiningDate;
        staff.address = address;
        staff.active = active;

        editMode = false;
        editingStaffId = null;
        formTitle.textContent = "Add Staff Member";
        submitButton.textContent = "Add Staff Member";
    } else {
        // Add New Staff Member
        const newStaff = {
            id: Date.now(),
            name,
            email,
            joiningDate,
            address,
            active
        };
        staffMembers.push(newStaff);
    }

    renderStaffTable();
    staffForm.reset();
});

// Render Staff Table
function renderStaffTable() {
    staffTable.innerHTML = "";
    staffMembers.forEach(staff => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${staff.id}</td>
            <td>${staff.name}</td>
            <td>${staff.email}</td>
            <td>${staff.joiningDate}</td>
            <td>${staff.address}</td>
            <td>${staff.active ? "Active" : "Inactive"}</td>
            <td class="actions">
                <button class="edit-btn" onclick="editStaff(${staff.id})">Edit</button>
                <button class="delete-btn" onclick="deleteStaff(${staff.id})">Delete</button>
                <button class="toggle-btn" onclick="toggleStaffStatus(${staff.id})">${staff.active ? "Deactivate" : "Activate"}</button>
            </td>
        `;

        staffTable.appendChild(row);
    });
}

// Edit Staff Member
function editStaff(id) {
    const staff = staffMembers.find(staff => staff.id === id);

    document.getElementById("name").value = staff.name;
    document.getElementById("email").value = staff.email;
    document.getElementById("joiningDate").value = staff.joiningDate;
    document.getElementById("address").value = staff.address;
    document.getElementById("active").checked = staff.active;

    editMode = true;
    editingStaffId = id;
    formTitle.textContent = "Edit Staff Member";
    submitButton.textContent = "Update Staff Member";
}

// Delete Staff Member
function deleteStaff(id) {
    if (confirm("Are you sure you want to delete this staff member?")) {
        staffMembers = staffMembers.filter(staff => staff.id !== id);
        renderStaffTable();
    }
}

// Toggle Staff Member Status (Activate/Deactivate)
function toggleStaffStatus(id) {
    const staff = staffMembers.find(staff => staff.id === id);
    staff.active = !staff.active;
    alert(`Staff "${staff.name}" is now ${staff.active ? "Active" : "Inactive"}.`);
    renderStaffTable();
}
