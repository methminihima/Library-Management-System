document.getElementById("borrow-form").addEventListener("submit", function (event) {
    event.preventDefault();

    // Get form values
    const borrowerId = document.getElementById("borrower-id").value;
    const staffId = document.getElementById("staff-id").value;
    const bookTitle = document.getElementById("book-title").value;
    const borrowDate = document.getElementById("borrow-date").value;
    const dueDate = document.getElementById("due-date").value;

    // Validate input
    if (!borrowerId || !staffId || !bookTitle || !borrowDate || !dueDate) {
        document.getElementById("error-message").textContent = "All fields are required.";
        return;
    }

    // Success
    alert(`Borrow details saved successfully!\n\nBorrower ID: ${borrowerId}\nStaff ID: ${staffId}\nBook Title: ${bookTitle}\nBorrow Date: ${borrowDate}\nDue Date: ${dueDate}`);
    document.getElementById("borrow-form").reset();
});
